1+3
4+4
5/2
6*5
70/7
5%%2
5-1
200%/% 3
200<50
400<=400
5!=5
isTRUE(TRUE)
isTRUE(FALSE)
isTRUE(3<2)
isTRUE(3>2)
x=2
y<-4
z<<-8

x
y
z

x<-1:10
x

x<5
x[x<5]

x[x<9 | x>5]
x[x<9 & x>5]

v = c(1,2,3,4,5)
v

v1<-c("hello","hi","ann")
v1
v2<-c(TRUE,TRUE,FALSE,FALSE)
v2
class(v2)
class(v1)
v4<-c(10,12,14)
class(v4)
v4+2
v4>12

a<-v4[v>12]
a
v4[2]
v4[-2]

#sequence
seq(1:15)
seq(5:10)
seq(5,10)

seq(1,15,by=5)
seq(1,15,by=3)
rep(5,3)
rep(1:4,3)
rep(1:4,each=3)
rep(1:4,each=4)

rep(1:5,1:5)
rep(1:3,c(2,5,4))
f<-c("f","a","b","f")
f
class(f)
factor(f)

sort(v4)
length(v4)

